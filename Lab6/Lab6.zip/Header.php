<?php
	echo "<div id=\"header\">";
	include_once "Menu.php";
	echo "<h1>8238 WEB PROGRAMMING</h1></div>";
?>