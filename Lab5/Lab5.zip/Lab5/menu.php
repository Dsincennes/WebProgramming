<?php

echo 	"<div id=\"menu\">
<br>
<a href=\"http://donalds.sgedu.site/Lab2\">Lab2</a>
<a href=\"http://donalds.sgedu.site/Lab3\">Lab3</a>
<a href=\"http://donalds.sgedu.site/Lab4\">Lab4</a>
 </div>";

?>