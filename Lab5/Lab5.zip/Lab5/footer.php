<?php

$studentNumber = "041011305";
$emailAddress = "sinc0138@algonquinlive.com";
	echo "<div id=\"footer\">";
	echo "<br>";
	echo "<strong>" .$studentNumber."<br>".$emailAddress."</strong>";
	echo "</div>";
?>